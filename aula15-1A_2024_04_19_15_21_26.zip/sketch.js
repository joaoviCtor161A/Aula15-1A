//preparar e rodar um codigo
function setup() {
  createCanvas(1000 ,1000 );//criar tela
 background("pink")//função para pintar o fundo
}

//responsável por desenhar 
function draw() {
  stroke("blue");
  fill("red");

  if(mouseIsPressed) {
    rect(mouseX, mouseY, 40, 40);
  }
}
